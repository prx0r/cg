"""Project demo.signal_game results into the HydraDB experience graph.

Per-world isolation: policy keys are qualified with the world kind, and this
world's runner targets graph id "cogym-demo" (falls back to the shared "cogym"
graph automatically when the server ACL has not authorized that scope yet).
"""
from __future__ import annotations

from ..experience.projection import GraphOps, project_performance, project_delta
from ..core.contracts import EpisodeRecord

FAMILY = "demo.signal_game"
BASELINE_POLICY_ID = "demo.reckless_v1"


def ops_from_records(records: list[EpisodeRecord]) -> GraphOps:
    """Aggregate episode records per candidate -> RAN_ON (+ delta vs control)."""
    ops = GraphOps()
    by_candidate: dict[str, list[EpisodeRecord]] = {}
    for r in records:
        by_candidate.setdefault(r.candidate_id, []).append(r)

    def mean(rs, name):
        vals = [r.metrics.get(name) for r in rs]
        vals = [v for v in vals if v is not None]
        return sum(vals) / len(vals) if vals else None

    control = mean(by_candidate.get(BASELINE_POLICY_ID, []), "cash_cost")
    for cand_id, rs in by_candidate.items():
        project_performance(
            ops, f"{FAMILY}:{cand_id}", FAMILY, kind_label="candidate",
            direction_accuracy=mean(rs, "correct"),
            quality_pass=all((r.metrics.get("correct") or 0) >= 1.0 for r in rs),
            )
        edge = ops.edges[-1]
        c = mean(rs, "cash_cost")
        if c is not None:
            edge.props["cash_cost"] = round(c, 6)
        if control is not None and c is not None:
            # lower cost than control counts as improvement (utility in -cost terms)
            project_delta(ops, f"{FAMILY}:{cand_id}", FAMILY,
                          (control - c) * 1e4, vs=BASELINE_POLICY_ID)
    return ops
