# demo — a cogym world (scaffold v4)

**Kind:** `demo.signal_game` · **Created:** 2026-08-24 02:27 UTC
template validation world for the scaffolder

This package was spawned complete and runnable by `cogym world-new`. Replace
the starter SignalGame with your domain; keep the wiring.

## Run it now (30 seconds)

```bash
cd canonical
python3 -m cogym.worlds.demo.runner --generations 2
```

You just: evaluated a population on a frozen suite -> projected results into
HydraDB -> proposed hydra-informed children -> promoted under quality gates ->
appended an immutable receipt to `experiments/demo-auto/outputs/`.

## Where things live

| File | Role |
|------|------|
| `world.py` | the World (state/obs/actions/transitions/score) + starter policies |
| `experience.py` | this world's projection into the Hydra experience graph |
| `runner.py` | the evolution loop (evaluate → project → propose → promote) |
| `AGENTS.md` | standing instructions for coding agents |

## The contract (non-negotiable, factminer.md §0)

1. **World ≠ policy ≠ evaluator.** `world.apply()` never does I/O; executors do.
2. **Quality is a constraint.** Gates dominate objectives; cheap garbage dies.
3. **No LLM grades itself.** Scoring is deterministic against `score()`.
4. **Hydra is memory, not truth.** Receipts in `experiments/demo-auto/outputs/`
   are canonical; the graph can be wiped and rebuilt from them anytime.

## Evolutionary use

Candidates are `CandidateArtifact(kind="demo_policy", config={...})`.
Mutations change CONFIG (strategy knobs, budgets, thresholds), never the
evaluator. The runner's `ExperienceLoop` reads top historical policies from
Hydra before proposing and writes every generation back — that feedback loop
IS the evolutionary mechanism. Cross-world learning is a query away because all
worlds share the experience-graph schema (`REL_RAN_ON`, `REL_IMPROVED_ON`, …).

## Adapting the starter to your world

Search `world.py` for `@@ADAPT:` markers. Typical order:
1. `reset()` — load real instances (dataset rows, scenarios)
2. `actions()` — your typed action set + honest `estimated_cost`
3. `apply()` / `terminal()` — dynamics
4. `score()` — your hard-quality metric + cost + latency
5. `policies` — baseline (strong) and control (cheap garbage) arms
Then re-run the smoke above; the whole lab (campaign, gates, hydra, receipts)
works unchanged.

## Operating autonomously

```bash
cd canonical
setsid nohup python3 -m cogym.worlds.demo.runner --generations 10 \
  > ../../logs/demo-auto.log 2>&1 &
tail -5 ../../logs/demo-auto.log     # watchdog every 30–60s
```
