#!/usr/bin/env python3
"""Autonomous evolution runner for demo.signal_game.

Usage (foreground smoke):   python3 -m cogym.worlds.demo.runner --generations 2
Usage (autonomous):         cd canonical && \
  setsid nohup python3 -m cogym.worlds.demo.runner --generations 10 \\
    > ../../logs/demo-auto.log 2>&1 &

Protocol (docs/factminer.md §58, repo Autonomous Experiment Mode):
  1. population evaluated on frozen suite (paired instances, fixed seeds)
  2. generation projected into the HydraDB experience graph
  3. children proposed: hydra-informed when leaders exist, deterministic otherwise
  4. receipts appended to outputs/demo-receipts.jsonl (append-only, canonical)
  5. promotion = quality gate PASS, ranked cost -> latency (lexicographic)
Never edit gates/evaluator mid-campaign; freeze changes between runs.
"""
from __future__ import annotations
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))

from cogym.core.campaign import (Campaign, CampaignConfig, aggregate,
                                 gates_pass, rank_population)
from cogym.core.contracts import CandidateArtifact
from cogym.core.evaluation import Objective, QualityGate
from cogym.core.runtime import GenericRunner
from cogym.core.toy_executor import DeterministicExecutor
from cogym.experience.client import HydraClient
from cogym.experience.loop import ExperienceLoop, run_campaign_with_experience
from cogym.worlds.registry import create

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "..", "..", "..", "experiments", "demo-auto", "outputs")

SUITE = (("s1", 11), ("s2", 22), ("s3", 33), ("s4", 44))   # freeze before runs
GATES = (QualityGate(metric="correct", mode="max", value=1.0),)
OBJECTIVES = (Objective("cash_cost", "min"), Objective("wall_latency_ms", "min"))


def policy_factory(cand: CandidateArtifact):
    from . import world as W
    cfg = dict(cand.config or {})
    if "steps" in cfg:
        inst = W.StepChainPolicy(cfg)
    else:
        name = cfg.get("policy", "CautiousPolicy")
        inst = getattr(W, name, W.CautiousPolicy)()
    inst.policy_id = f"{cand.kind}:{cand.candidate_id[:16]}"   # per-artifact identity
    return inst


def append_receipt(path: str, record: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a") as fh:
        fh.write(json.dumps(record, sort_keys=True, default=str) + "\n")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--generations", type=int, default=3)
    ap.add_argument("--population", type=int, default=6)
    args = ap.parse_args()

    runner = GenericRunner(executors={"deterministic": DeterministicExecutor()})
    world_fn = lambda inst: create("demo.signal_game")
    cfg = CampaignConfig(world_kind="demo.signal_game", suite=SUITE, gates=GATES,
                         objectives=OBJECTIVES, generations=args.generations,
                         population=args.population, elite_k=2)
    campaign = Campaign(cfg, runner, world_fn, propose_fn=lambda p, n: [])
    loop = ExperienceLoop(HydraClient())
    print(f"[demo] hydra experience: {loop.enabled}", flush=True)

    seeds = [CandidateArtifact(kind="demo_policy", version="1",
                               config={"policy": n})
             for n in ("CautiousPolicy", "RecklessPolicy")]
    t0 = time.time()
    winners = run_campaign_with_experience(campaign, seeds, policy_factory,
                                           loop=loop)
    receipt = {
        "ts": time.time(),
        "world": "demo.signal_game",
        "generations": args.generations,
        "winners": [w.candidate_id[:24] for w in winners],
        "configs": [w.config for w in winners],
        "stats": vars(loop.stats),
        "elapsed_s": round(time.time() - t0, 1),
    }
    append_receipt(os.path.join(OUT_DIR, "demo-receipts.jsonl"), receipt)
    print(json.dumps(receipt, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
