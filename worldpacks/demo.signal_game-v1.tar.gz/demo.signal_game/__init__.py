"""demo world package (scaffolded). See README.md."""
