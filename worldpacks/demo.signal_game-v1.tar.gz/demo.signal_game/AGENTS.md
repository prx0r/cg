# AGENTS.md — demo world

Read `../AGENTS.md` (canonical conventions) first. This file adds world-local rules.

## For agents evolving this world

1. Evolve **configs**, not evaluators. `CandidateArtifact.config` is the genome.
2. Never touch `GATES`, `SUITE`, or `score()` mid-campaign — freeze, then run.
   Changes between campaigns require a fresh receipt line explaining why.
3. Fresh session/state per evaluation; paired instances come from `SUITE`.
4. n_decided < 30 ⇒ PILOT mode: findings are directional, say so explicitly.
5. Hydra (`experience.py`, `ExperienceLoop`) is derived memory. If it is down,
   the runner still works; report `"hydra": false` honestly instead of retrying forever.
6. Receipts are append-only. Never rewrite `outputs/demo-receipts.jsonl`.

## Turning this template into the intended world

- Grep `@@ADAPT:` in `world.py` — each marker is a swap point.
- Keep the public observation free of oracle data (hidden labels stay out).
- Add phenotype/action variety BEFORE adding cleverness: the attack surface
  (action space) is what evolution exploits.
- Register new policies in `world.py` (or `policies.py` when config-driven) and
  expose them via `policy_factory` in `runner.py`.

## Useful queries against the experience graph (HTTP :8443)

```python
from cogym.experience.client import HydraClient
c = HydraClient(graph="cogym-demo")           # ACL fallback: HydraClient()
top = c.query(
  "MATCH (e:REL_RAN_ON {dst_key: $f}) WHERE e.quality_pass = true "
  "RETURN e.src_key AS pk, e.cash_cost AS cost ORDER BY cost ASC LIMIT 5",
  {"f": "worldfamily:demo.signal_game"}, columns=("pk", "cost"))
```

Vendored upstream docs: `docs/hydradb/` in the repo root (README,
architecture, cypher-compat, plus our INTEGRATION-NOTES with verified quirks).
